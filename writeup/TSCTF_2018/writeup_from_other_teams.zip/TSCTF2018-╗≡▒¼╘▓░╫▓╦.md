# TSCTF2018-火爆圆白菜‎٩(๑òωó๑)۶-writeup
## 0x00 我需要治疗
我需要治疗：
Base64解码，贴到微信公众号里即可。
## 0x01 Are you in class:
查看源码，禁用js后随便贴一个数据有`You are not in CLA55!!!!You are hanging outside!!!`

hint出来之后猜测是x-forward-for ip伪造，于是ip为内网得到`flag`。

## 0x02  easycalc
拿到文件之后，先到ida里看一下。`F5`之后发现在`main`函数第66行有这样一句
```
v13[v5] = v7;
```
之前的代码在修改数组值时都有对下标的限制，而这里没有，而且函数列表里又给出了一个`hackhere`函数，于是打算尝试一波栈溢出修改返回地址的操作。
一开始以为数组的第一个元素位置在`EBP-70h`，而希望修改的位置在`EBP+4`，于是修改的位置应该是数组的第116位左右，但拿到`GDB`里改完发现没有任何变化orz，但发现是一次改两位，也就是题目里说的`（0<x<256）`。
于是直接拿到`GDB`里调出返回地址的值，在栈里找到这个值，和数组第一个元素的地址做差，得到应该修改的位置。然后手动修改数组的`132`、`133`、`134`、`135`数据为`155`、`133`、`4`、`8`，执行`5.exit`后在`/tmp`文件夹中得到`flag`。

## 0x03 gobang
一个下五子棋的题，限时很短，但发现当键入错误命令时，时间会重置，于是找了一个比较简单的开局，一边不停敲上方向键，一边下棋，得到`flag`。

## 0x04 简单的RSA
拿到.pmg文件后仔细观察发现左上角有迷之像素点，拖到iHex里发现e、n和cipher，拿到python里转十进制后再用[http://factordb.com](https://http://factordb.com)分解一波p、q，再用`d = gmpy2.invert(e, (p-1)*(q-1))`求一波d，最后`print(hex(pow(c,d,n)))`得到flag。

## 0x05 正常的魔塔
魔塔是典型的RPG游戏，拿到游戏后先玩了一会，发现正常的玩法，没有足够的钥匙，角色也没有足够的能力值，很难走到顶层，打开文件夹发现是典型的RPG Maker XP的格式，于是使用RPG Maker XP创建了一个新的Project，并将正常的魔塔中的data文件夹覆盖了Project的data文件夹，发现能够正常的打开数据库。

在公共事件中开门事件中增加了一系列的增益之后，钥匙数量和能力值都大大提高，接下来控制角色一路走到50层，并与npc对话得到了flag

## 0x06 zhiyu的短视频
题目的文件是一个swf文件，尝试用flash打开，提示文件被保护使用free flash decompiler对该文件进行反编译，hint中提示元件，打开图形文件夹后发现有一张几乎完全透明的图像，仔细看发现上面有一串字母，简单p了一下，得到这样一张图片，上面有两段字符串


仔细观察后发现，有部分子串是相同的例如ggll，dggg和fgh，经过搜索发现分别是汉字一，三和十五笔对应的输入，于是下载了五笔输入法，完全输入后得到“一三五七八十腊，三十一天永不差”的一句谚语，取其中的数字“135781031”发现不正确，后来想腊是中国的十二月，于是用TSCTF{135789101231}就成功了

## 0x07 Buy Flag				
拿到网页后，发现实际能操作的就只有登录和注册窗口，打开注册窗口，发现年龄小于18岁都无法进行注册，随便注册个账号后发现有一下的界面，其中`
There are    littleprince,maihuochaidexiaonvhai,meirenyu.etc    that are younger than you have been registered too!`中有诡异的空格。根据语义判断可能是根据输入的年龄对数据库进行了搜寻，有可能存在注入点。

尝试在年龄栏中填入`-1’ and 1=2`后被提示必须为数字
再尝试十六进制数输入`0x22`发现可以成功注册，怀疑可能有对十六进制进行解码的过程，于是使用字符串转十六进制的方法进行注入。
首先先进行了尝试将`-1’ and 1=2#`转16进制后提交，登陆后发现主界面发生了变化

肯定了存在注入点，于是使用order by进行猜测，一开始使用`-1' and 1=2 order by 3#`
发现登陆后界面白屏，直到`-1' order by 1#`时才出现以下界面：
`Order by 1`

发现只显示一个字段后，进行库名的爆破，使用-
`1'and 1=2 union select group_concat(schema_name) from information_schema.schemata# `提交后得到库名childhappy

然后使用`select group_concat(table_name) from information_schema.tables where table_schema='happychild'#`爆出表名py_flag

然后使用`-1' and 1=2 union select group_concat(column_name) from information_schema.columns where table_schema='childhappy'#`爆出列名，发现存在TSCTF_fal9,怀疑最终的flag就存在于TSCTF_fla9中

于是想从py_flag表中将tsctf_fla9脱下来，就使用`-1' and 1=2 union select group_concat(tsctf_fla9) from py_flag#`
最后成功得到了flag：TSCTF{Simple_Sql_f0r_Y0u}



